# mizquotes_lambda
Miz quotes alexa skill lambda enabled
